<?php
    $sujs=$_GET['sjs'];
    echo "A sua mensagem '$sujs', foi redirecionada para o responsavel devido "
?>