
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>atividade triagulo</title>
</head>
<body>
    <div id="inputs">
        <form method="get" action="cu.php">
        <p><input id='int'type="text" name="x" placeholder="x"></p>
        <p><input id='int'type="text" name="y" placeholder="y"></p>
        <p><input id='int'type="text"name="z"  placeholder="z"></p>
        <p><input type="submit" id="int" name="OK"></p>
        </form>
    </div>
    <style>
        #inputs{
            background-color: gray;
            height: 200px;
            width: 200px;
        }
        #int {
            margin-top: 10px;
            margin-left: 10px;
        }
    </style>
</body>
</html>