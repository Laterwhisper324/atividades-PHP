<?php
function tri($l1,$l2,$l3){
  if ($l1==$l2 && $l2==$l3 && $l1==$l3){
    echo "Triangulo Equilatero";
  }elseif($l1==$l2 && $l2!=$l3 && $l1!=$l3){
    echo "Triangulo Isosceles";
  }else if($l1!=$l2 && $l2!=$l3 && $l1!=$l3){
  echo "triangulo escaleno";
  }else{
    echo "nao é um triangulo";
  }
}
$l1=$_GET['x'];
$l2=$_GET['y'];
$l3=$_GET['z'];
echo tri($l1,$l2,$l3);

?>