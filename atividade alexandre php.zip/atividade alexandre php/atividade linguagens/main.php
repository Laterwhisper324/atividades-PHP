<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>atividade</title>
</head>
<body>
    <div id="main">
        <center>
        <h2>Escolha uma Linguagem</h2>
        </center>
        <form action="get" method="index.php">
        <div id="lings">
            <p><input name="linguagem" type="radio" value="php"> php</p>
            <p><input name="linguagem" type="radio" value="html"> html/css</p>
            <p><input name="linguagem" type="radio" value="cb"> cobol</p>
            <p><input name="linguagem" type="radio" value="py"> python</p>
        </div>
        <input type="submit" value="enviar">
        </form>
    </div>
    <style>
        #main{
            background-color: gray;
            height: 260px;
            width: 200px;
            border-radius: 5px;
        }
        #lings p{
            background-color: blue;
            border: 2px solid black;
        }
    </style>
</body>
</html>