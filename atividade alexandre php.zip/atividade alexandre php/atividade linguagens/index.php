<?php
    $lings=$_GET['linguagem'];
    if($lings=="php"){
        echo "<h1>$lings, essa linguagem é back end</h1>";
    }
    if($lings=="html"){
        echo "<h1>$lings, essa linguagem é front end</h1>";
    }
    if($lings=="py"){
        echo "<h1>$lings, essa linguagem é front end</h1>";
    }
    if($lings=="cb"){
        echo "<h1>$lings, essa linguagem é back end</h1>";
    }
?>