<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>atividade</title>
</head>
<body>
    <form action="get" method="index.php">
        <div id="main">
            <center><h2>lista estado</h2></center>
            <p><select name="est">
                <option value="capixaba">espirito santos</option>
                <option value="minero">minas gerais</option>
                <option value="paulista">sao paulo</option>
                <option value="carioca">rio de janeiro</option>
            </select></p>
            <p><input type="text" name="nome" placeholder="nome"></p>
            <p><input type="submit" name="OK"></p>
        </div>
    </form>
    <style>
        #main{
            background-color: gray;
            height: 200px;
            width: 200px;
            border-radius: 20px;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
        }
        #main select{
            margin-top: 20px;
            margin-left: 10px;
        }
        #main input{
            margin-left: 10px;
        }
    </style>
</body>
</html>