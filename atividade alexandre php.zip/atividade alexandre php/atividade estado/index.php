<?php
    $nome=$_GET['nome'];
    $estado=$_GET['est'];
    echo "ola $nome voce é de $estado";
?>